import React from 'react';
import { Link } from 'react-router-dom';
import './Dashboard.css'; // Create this CSS file for styling

const Dashboard = () => {
  return (
    <div className="dashboard-container">
      <h2>Dashboard</h2>
      <Link to="/transaction" className="link-button">
        <button className="go-to-transaction-button">Go to Transactions</button>
      </Link>
    </div>
  );
};

export default Dashboard;
