// api.js
import axios from 'axios';

const API_URL = 'https://jsonbin.io/app/bins'; // Replace with your actual API URL

export const getBalance = async (accountNumber) => {
  const response = await axios.get(`${API_URL}/balance/${accountNumber}`);
  return response.data.balance; // Adjust based on your API response structure
};

export const deposit = async (accountNumber, amount) => {
  const response = await axios.post(`${API_URL}/deposit`, {
    accountNumber,
    amount,
  });
  return response.data; // Adjust based on your API response structure
};

export const withdraw = async (accountNumber, amount) => {
  const response = await axios.post(`${API_URL}/withdraw`, {
    accountNumber,
    amount,
  });
  return response.data; // Adjust based on your API response structure
};
