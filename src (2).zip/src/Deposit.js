import React, { useState } from 'react';
import './DepositForm.css'; // Assuming you'll add custom styles for the form

function DepositForm({ onCancel, onDeposit }) {
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (accountNumber && amount) {
      onDeposit(Number(amount));
    }
  };

  return (
    <form className="deposit-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="accountNumber">Account Number</label>
        <input
          type="text"
          id="accountNumber"
          className="form-control"
          value={accountNumber}
          onChange={(e) => setAccountNumber(e.target.value)}
          required
        />
      </div>
      <div className="form-group">
        <label htmlFor="amount">Amount</label>
        <input
          type="number"
          id="amount"
          className="form-control"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
      </div>
      <div className="form-group button-group">
        <button type="button" className="btn btn-danger" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn btn-primary">
          Deposit
        </button>
      </div>
    </form>
  );
}

export default DepositForm;



