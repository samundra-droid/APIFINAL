import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Signin.css'; // Assuming you have some custom styling

const SignIn = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const navigate = useNavigate();

    const handleSignIn = async (e) => {
        e.preventDefault();
        
        try {
            // Fetch user data from JSONBin
            const response = await axios.get('https://api.jsonbin.io/v3/b/66f38cddacd3cb34a88ad470/latest', {
                headers: {
                    'X-Master-Key': '$2a$10$UFcjl85dKs1.cmHswMhYdOz2GUchtzRzJ9MxbJ/R39O5bvnB/KGYq'
                }
            });

            const users = response.data.record?.users || [];
            const user = users.find(user => user.email === email && user.password === password);

            if (user) {
                setMessage('Login successful!');
                navigate('/dashboard'); // Redirect to dashboard
            } else {
                setMessage('Invalid email or password.');
            }
        } catch (error) {
            console.error('Error logging in:', error);
            setMessage('Error logging in: ' + (error.response?.data?.message || error.message));
        }
    };

    return (
        <div className="signin-container">
            <h2>Sign In</h2>
            <form onSubmit={handleSignIn}>
                <label>
                    Email Address:
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </label>
                <label>
                    Password:
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </label>
                <button type="submit">Sign In</button>
            </form>
            {message && <p className="message">{message}</p>}
        </div>
    );
};

export default SignIn;


