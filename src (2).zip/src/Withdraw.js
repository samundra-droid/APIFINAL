import React, { useState } from 'react';
import DepositForm from './DepositForm';
import DepositButton from './DepositButton';

function WithdrawalForm() {
  const [balance, setBalance] = useState(0);
  const [showDepositForm, setShowDepositForm] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');

  const handleDeposit = (amount) => {
    setBalance((prevBalance) => prevBalance + amount);
    setShowDepositForm(false); // Hide deposit form after deposit
  };

  const handleWithdraw = (e) => {
    e.preventDefault();
    const amount = Number(withdrawAmount);
    if (amount > 0 && amount <= balance) {
      setBalance((prevBalance) => prevBalance - amount);
      setWithdrawAmount('');
    } else {
      alert('Invalid withdrawal amount');
    }
  };

  return (
    <div className="withdrawal-container">
      <h2>Current Balance: ${balance}</h2>

      {/* Withdrawal Form */}
      <form onSubmit={handleWithdraw}>
        <div className="form-group">
          <label htmlFor="withdrawAmount">Withdraw Amount</label>
          <input
            type="number"
            id="withdrawAmount"
            className="form-control"
            value={withdrawAmount}
            onChange={(e) => setWithdrawAmount(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-warning">
          Withdraw
        </button>
      </form>

      {/* Show Deposit Button or Form */}
      {showDepositForm ? (
        <DepositForm
          onCancel={() => setShowDepositForm(false)}
          onDeposit={handleDeposit}
        />
      ) : (
        <DepositButton onClick={() => setShowDepositForm(true)} />
      )}
    </div>
  );
}

export default WithdrawalForm;