import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

function Signup() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState(''); // Added for password confirmation
  const [message, setMessage] = useState('');
  const [storedData, setStoredData] = useState([]); // Ensure it's an array

  // Handle signup logic
  const handleSignup = (e) => {
    e.preventDefault();

    // Password validation
    if (password !== confirmPassword) {
      setMessage('Passwords do not match');
      return;
    }

    // Create new user object
    const userData = {
      username,
      email,
      password,
      accountNumber: Math.floor(Math.random() * 10000).toString(), // Generate random account number
      balance: "0", // Initial balance for a new user
    };

    // Merge new user data with the existing stored data
    const newData = [...storedData, userData];
    const data = JSON.stringify({ users: newData });

    // Config for PUT request
    const config = {
      method: 'PUT',
      url: 'https://api.jsonbin.io/v3/b/66f38cddacd3cb34a88ad470', // Correct bin URL
      headers: {
        'Content-Type': 'application/json',
        'X-Master-Key': '$2a$10$UFcjl85dKs1.cmHswMhYdOz2GUchtzRzJ9MxbJ/R39O5bvnB/KGYq', // Correct key
      },
      data: data,
    };

    // Perform PUT request to save new user data
    axios(config)
      .then((response) => {
        setMessage('Signup successful! User data stored.');
        fetchStoredData(); // Refresh stored data
        clearForm(); // Clear input fields
      })
      .catch((error) => {
        console.error('Error:', error.response ? error.response.data : error.message); // Improved error logging
        setMessage('Signup failed.');
      });
  };

  // Fetch stored data from JSONBin
  const fetchStoredData = () => {
    const config = {
      method: 'GET',
      url: 'https://api.jsonbin.io/v3/b/66f38cddacd3cb34a88ad470/latest',
      headers: {
        'X-Master-Key': '$2a$10$UFcjl85dKs1.cmHswMhYdOz2GUchtzRzJ9MxbJ/R39O5bvnB/KGYq',
      },
    };

    // Perform GET request to fetch stored data
    axios(config)
      .then((response) => {
        // Ensure the users field is an array
        setStoredData(Array.isArray(response.data.record?.users) ? response.data.record.users : []);
      })
      .catch((error) => {
        console.error('Error fetching stored data:', error.response ? error.response.data : error.message);
      });
  };

  // Clear form fields after successful signup
  const clearForm = () => {
    setUsername('');
    setEmail('');
    setPassword('');
    setConfirmPassword(''); // Reset confirm password field
  };

  // Fetch stored user data on component mount
  useEffect(() => {
    fetchStoredData();
  }, []);

  return (
    <div className="container mt-5">
      <h2>Signup</h2>
      <form onSubmit={handleSignup} className="mb-4">
        <div className="mb-3">
          <label className="form-label">Username:</label>
          <input
            type="text"
            className="form-control"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Email:</label>
          <input
            type="email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Password:</label>
          <input
            type="password"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Confirm Password:</label>
          <input
            type="password"
            className="form-control"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Signup</button>
      </form>
      {message && <div className="alert alert-info">{message}</div>}

      <h3>Stored User Data</h3>
      {storedData.length > 0 ? (
        <pre>{JSON.stringify(storedData, null, 2)}</pre>
      ) : (
        <p>No users found.</p>
      )}
    </div>
  );
}

export default Signup;

