import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "bootstrap/dist/css/bootstrap.min.css";

const Transaction = () => {
  const [showDepositForm, setShowDepositForm] = useState(false);
  const [showWithdrawForm, setShowWithdrawForm] = useState(false);
  const [transactions, setTransactions] = useState([]);
  const [users, setUsers] = useState([]); // Store user data (account info and balance)
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [nextId, setNextId] = useState(1);

  useEffect(() => {
    // Fetch existing transactions and users from JSON bin on component mount
    fetchTransactionsAndUsers();
  }, []);

  const fetchTransactionsAndUsers = async () => {
    try {
      const response = await fetch('https://api.jsonbin.io/v3/b/66f38cddacd3cb34a88ad470/latest', {
        method: 'GET',
        headers: {
          'X-Master-Key': '$2a$10$UFcjl85dKs1.cmHswMhYdOz2GUchtzRzJ9MxbJ/R39O5bvnB/KGYq',
        },
      });

      const data = await response.json();
      const existingTransactions = data.record.transactions || [];
      const existingUsers = data.record.users || [];
      
      setTransactions(existingTransactions);
      setUsers(existingUsers);

      // Set the next transaction ID
      if (existingTransactions.length > 0) {
        const maxId = Math.max(...existingTransactions.map(t => t.id));
        setNextId(maxId + 1);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleDeposit = () => {
    setShowDepositForm(true);
    setShowWithdrawForm(false);
  };

  const handleWithdraw = () => {
    setShowWithdrawForm(true);
    setShowDepositForm(false);
  };

  const handleTransactionSubmit = async (type) => {
    const newAmount = parseFloat(amount); // Convert input amount to a number
    const currentUser = users.find(user => user.accountNumber === accountNumber); // Find the current user by account number
    
    if (!currentUser) {
      alert('Account number not found.');
      return;
    }

    // Get the current balance of the user
    const currentBalance = parseFloat(currentUser.balance);

    // Calculate the new balance based on the transaction type
    let newBalance;
    if (type === 'Deposit') {
      newBalance = currentBalance + newAmount;
    } else if (type === 'Withdraw') {
      if (newAmount > currentBalance) {
        alert('Insufficient funds for this withdrawal.');
        return;
      }
      newBalance = currentBalance - newAmount;
    }

    const transactionId = nextId;

    // Create the new transaction object
    const newTransaction = {
      id: transactionId,
      accountNumber,
      type,
      amount: newAmount.toString(),
      date: new Date().toISOString().split('T')[0], // Get current date in YYYY-MM-DD format
      balance: newBalance,
    };

    // Update the user's balance in the users array
    const updatedUsers = users.map(user =>
      user.accountNumber === accountNumber ? { ...user, balance: newBalance } : user
    );

    // Update the transactions and users in JSON bin
    try {
      const updatedTransactions = [...transactions, newTransaction];

      await fetch('https://api.jsonbin.io/v3/b/66f38cddacd3cb34a88ad470', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'X-Master-Key': '$2a$10$UFcjl85dKs1.cmHswMhYdOz2GUchtzRzJ9MxbJ/R39O5bvnB/KGYq',
        },
        body: JSON.stringify({ users: updatedUsers, transactions: updatedTransactions }),
      });

      setTransactions(updatedTransactions);
      setUsers(updatedUsers); // Update users with new balance
      setNextId(transactionId + 1);
      setAmount(''); // Clear the amount input
      alert(`Transaction successful! New balance: ${newBalance}`);
    } catch (error) {
      console.error('Error updating transactions:', error);
      alert('Transaction failed.');
    }
  };

  const handleCancel = () => {
    setShowDepositForm(false);
    setShowWithdrawForm(false);
    setAccountNumber('');
    setAmount('');
  };

  return (
    <div className="container">
      <h2 className="text-center my-4">Transaction Page</h2>
      <div className="text-center">
        <button className="btn btn-success mx-2" onClick={handleDeposit}>
          Deposit
        </button>
        <button className="btn btn-danger mx-2" onClick={handleWithdraw}>
          Withdraw
        </button>
      </div>

      {/* Deposit Form */}
      {showDepositForm && (
        <div className="mt-4">
          <h4>Deposit Form</h4>
          <div className="form-group">
            <label>Account Number</label>
            <input
              type="text"
              className="form-control"
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Amount</label>
            <input
              type="number"
              className="form-control"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
          <button className="btn btn-primary mt-2" onClick={() => handleTransactionSubmit('Deposit')}>
            Deposit
          </button>
          <button className="btn btn-secondary mt-2 mx-2" onClick={handleCancel}>
            Cancel
          </button>
        </div>
      )}

      {/* Withdraw Form */}
      {showWithdrawForm && (
        <div className="mt-4">
          <h4>Withdraw Form</h4>
          <div className="form-group">
            <label>Account Number</label>
            <input
              type="text"
              className="form-control"
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Amount</label>
            <input
              type="number"
              className="form-control"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
          <button className="btn btn-primary mt-2" onClick={() => handleTransactionSubmit('Withdraw')}>
            Withdraw
          </button>
          <button className="btn btn-secondary mt-2 mx-2" onClick={handleCancel}>
            Cancel
          </button>
        </div>
      )}

      {/* Transaction Output */}
      <div className="mt-5">
        {transactions.length > 0 ? (
          <>
            <h4>Transactions</h4>
            <div className="table-responsive">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Type</th>
                    <th>Account</th>
                    <th>Amount</th>
                    <th>Balance</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((transaction) => (
                    <tr key={transaction.id}>
                      <td>{transaction.id}</td>
                      <td>{transaction.type}</td>
                      <td>{transaction.accountNumber}</td>
                      <td>{transaction.amount}</td>
                      <td>{transaction.balance}</td>
                      <td>{transaction.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <p className="text-center">No transactions available.</p>
        )}
      </div>
    </div>
  );
};

export default Transaction;




